function [b] = bp_fir_win(f_L, f_U, N, f_S, win)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculates the coefficients of a N-th order FIR bandpass filter f
% for a given Bandwith B and center frequency f_0 [Hz] when using
% a sampling frequency of f_S [Hz].
% Parameter W (optinal) specifies the windowing function to be used
% (default: rectangular).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% >>> ToDo <<<<
b= 1;

end

