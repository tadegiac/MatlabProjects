function [b,a,K] = bp_iir_bilin(f_L, f_U, f_S, pw)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculates the coefficients of a 2nd order IIR bandpass filter 
% for given lower and upper band edge frequencies [Hz] when using
% a bilinear transform for the analog prototype filter (1) with prewarping 
% (pw = 'prewarp')or without prewarping (else).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% >>> ToDo <<<<
b= 1;
a = 1;
K = 1;

end

